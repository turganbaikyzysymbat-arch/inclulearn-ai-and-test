import tempfile
import unittest
from pathlib import Path

import app


class IncluLearnAITest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        app.DB_PATH = Path(self.temp.name) / "test.db"
        app.DB_DIR = Path(self.temp.name)
        app.init_db()
        self.client = app.app.test_client()
        response = self.client.post("/auth/register", json={
            "name": "Test Teacher",
            "email": "teacher@example.com",
            "password": "strongpass123",
        })
        assert response.status_code == 200

    def tearDown(self):
        self.temp.cleanup()

    def test_create_material_and_progress(self):
        response = self.client.post(
            "/api/materials",
            data={
                "title": "Мұрагерлік",
                "text": "Мұрагерлік бір кластың қасиеттерін басқа класқа береді.",
            },
        )
        self.assertEqual(response.status_code, 201)
        material_id = response.get_json()["id"]
        progress = self.client.post(
            f"/api/materials/{material_id}/progress",
            json={"completed": True, "score": 100},
        )
        self.assertEqual(progress.status_code, 200)
        self.assertEqual(progress.get_json()["score"], 100)

    def test_task_builder_validation_and_grading(self):
        response = self.client.post("/api/task-sets", json={
            "title": "Тест",
            "tasks": [
                {"type": "quiz", "question": "2 + 2?", "options": ["3", "4"], "answers": ["4"]},
                {"type": "matching", "question": "Сәйкестендіріңіз", "pairs": [
                    {"left": "CPU", "right": "Процессор"}, {"left": "RAM", "right": "Жедел жад"}
                ]},
                {"type": "open", "question": "Түсіндіріңіз", "expected": "Себебін атау керек"}
            ]
        })
        self.assertEqual(response.status_code, 201)
        task_id = response.get_json()["id"]
        grade = self.client.post(f"/api/task-sets/{task_id}/grade", json={
            "answers": ["4", {"0": "Процессор", "1": "Жедел жад"}, "Мәтіндік жауап"]
        })
        result = grade.get_json()
        self.assertEqual(grade.status_code, 200)
        self.assertEqual(result["score"], 100)
        self.assertIsNone(result["results"][2]["correct"])

    def test_task_builder_rejects_wrong_answer_key(self):
        response = self.client.post("/api/task-sets", json={
            "title": "Қате тест",
            "tasks": [{"type": "quiz", "question": "Сұрақ", "options": ["A", "B"], "answers": ["C"]}]
        })
        self.assertEqual(response.status_code, 400)

    def test_search_and_delete_material(self):
        response = self.client.post(
            "/api/materials",
            data={"title": "ООП", "text": "Бала класс әдістерді қолданады."},
        )
        material_id = response.get_json()["id"]
        found = self.client.get("/api/materials?q=ООП")
        self.assertEqual(len(found.get_json()["materials"]), 1)
        deleted = self.client.delete(f"/api/materials/{material_id}")
        self.assertEqual(deleted.status_code, 200)


if __name__ == "__main__":
    unittest.main()